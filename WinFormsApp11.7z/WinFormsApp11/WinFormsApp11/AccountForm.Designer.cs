﻿namespace WinFormsApp11
{
    partial class AccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelWelcome = new Label();
            labelBalance = new Label();
            buttonLogout = new Button();
            SuspendLayout();
            // 
            // labelWelcome
            // 
            labelWelcome.AutoSize = true;
            labelWelcome.Location = new Point(258, 83);
            labelWelcome.Name = "labelWelcome";
            labelWelcome.Size = new Size(38, 15);
            labelWelcome.TabIndex = 0;
            labelWelcome.Text = "label1";
            // 
            // labelBalance
            // 
            labelBalance.AutoSize = true;
            labelBalance.Location = new Point(258, 115);
            labelBalance.Name = "labelBalance";
            labelBalance.Size = new Size(38, 15);
            labelBalance.TabIndex = 1;
            labelBalance.Text = "label1";
            // 
            // buttonLogout
            // 
            buttonLogout.Location = new Point(258, 156);
            buttonLogout.Name = "buttonLogout";
            buttonLogout.Size = new Size(75, 23);
            buttonLogout.TabIndex = 2;
            buttonLogout.Text = "Выход";
            buttonLogout.UseVisualStyleBackColor = true;
            // 
            // AccountForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonLogout);
            Controls.Add(labelBalance);
            Controls.Add(labelWelcome);
            Name = "AccountForm";
            Text = "AccountForm";
            Load += AccountForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelWelcome;
        private Label labelBalance;
        private Button buttonLogout;
    }
}