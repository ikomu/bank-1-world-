﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class AccountForm : Form
    {
        private User currentUser;
        private decimal balance;
        private void AccountForm_Load(object sender, EventArgs e)
        {
            // Код, который вы хотите выполнить при загрузке формы
        }

        public AccountForm(User user)
        {
            InitializeComponent();
            currentUser = user;
            balance = 0; // Можно расширить, чтобы хранить баланс для каждого пользователя

            labelWelcome.Text = $"Добро пожаловать, {currentUser.Username}!";
            labelBalance.Text = $"Ваш баланс: {balance:C}";

            // Подписка на событие Load
            this.Load += new EventHandler(AccountForm_Load);
        }

        private void buttonLogout_Click(object sender, EventArgs e)
        {
            this.Close(); // Закрыть форму счета — вернёт пользователя на форму регистрации
        }
    }
}
